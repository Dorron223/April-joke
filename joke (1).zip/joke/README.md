# joke

A Pen created on CodePen.

Original URL: [https://codepen.io/nsvbnkqh-the-sasster/pen/pvoqJRX](https://codepen.io/nsvbnkqh-the-sasster/pen/pvoqJRX).

